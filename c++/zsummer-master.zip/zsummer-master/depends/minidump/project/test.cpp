#include <iostream>
#include "../MiniDump.h"
int main(int argc, char *argv[])
{
	zsummer::CMiniDump::GetInstance();

	char *p = NULL;
	*p =3;




	return 0;
}