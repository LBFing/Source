#pragma once

void master_creator();
