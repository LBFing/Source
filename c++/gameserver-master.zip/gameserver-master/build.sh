#!/bin/bash

cd Common
./build.sh

cd ../Login
./build.sh

cd ../Gate
./build.sh

cd ../Center
./build.sh

cd ../Client
./build.sh

cd ..