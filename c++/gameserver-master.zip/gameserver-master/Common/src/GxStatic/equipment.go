package GxStatic

import (
// "gopkg.in/redis.v3"
// "strconv"
// "sync"
)

type Equipment struct {
}
