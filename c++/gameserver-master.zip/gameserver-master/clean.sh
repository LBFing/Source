#!/bin/bash

rm -rf ./Common/pkg

rm -rf ./Gate/bin/gxgate
rm -rf ./Gate/bin/log
rm -rf ./Gate/bin/nohup.out

rm -rf ./Login/bin/gxlogin
rm -rf ./Login/bin/log
rm -rf ./Login/bin/nohup.out

rm -rf ./Center/bin/gxcenter
rm -rf ./Center/bin/log
rm -rf ./Center/bin/nohup.out


rm -rf ./Client/bin/gxclient
rm -rf ./Client/bin/log
rm -rf ./Client/bin/nohup.out

rm -rf ./Tool/bin/gx*
rm -rf ./Tool/bin/log

rm -rf ./nohup.out