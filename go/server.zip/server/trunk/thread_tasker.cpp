#include <unistd.h>
#include "thread_tasker.h"

int thread_tasker_t::process(int cfd, proc_func_t proc)
{
    process_thread_t *thread = new process_thread_t(cfd, proc);
    thread->start();
    thread->detach();
    // memory leak exsits
    return 0;
}

