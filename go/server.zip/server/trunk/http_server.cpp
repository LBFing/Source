#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <ctype.h>
#include <time.h>
#include <sys/stat.h>
#include <string>

#include "server_frame.h"
#include "simple_tasker.h"
#include "tpoll_tasker.h"
#include "thread_tasker.h"

#define SERVER_NAME "mini_http_server"
#define SERVER_ROOT "/root"
#define SERVER_URL "http://ydzhang.cublog.cn"
#define PROTOCOL "HTTP/1.0"
#define RFC1123FMT "%a, %d %b %Y %H:%M:%S GMT"

/* Forwards. */
static void file_details(FILE *fp,  char* dir, char* name );
static void send_error( FILE *fp, int status, char* title, char* extra_header, char* text );
static void send_headers( FILE *fp, int status, char* title, char* extra_header, char* mime_type, off_t length, time_t mod );
static char* get_mime_type( char* name );
static void strdecode( char* to, char* from );
static int hexit( char c );
static void strencode( char* to, size_t tosize, const char* from );
int do_http_task(int cfd);

int main()
{
   if ( chdir( SERVER_ROOT ) < 0 ) {
        perror("chdir");
        return -1;
   }

    server_frame_t server(new thread_tasker_t(), do_http_task);
    server.tcp_server("192.168.0.79", 12340);
    server.loop_task();
    return 0;
}

int
do_http_task(int cfd)
{
    FILE *fp = fdopen(cfd, "r+");
    if(NULL == fp) {
        close(cfd);
        return -1;
    }

    char line[10000], method[10000], path[10000], protocol[10000], idx[20000], location[20000], command[20000];
    char* file;
    size_t len;
    int ich;
    struct stat sb;
    struct dirent **dl;
    int i, n;


     if ( fgets( line, sizeof(line), fp ) == (char*) 0 ) { //��ȡ�����У��������󷽷���·����Э��
	    //send_error(fp, 400, "Bad Request", (char*) 0, "No request found." );
        close(cfd);
        return 0;
    }

    if ( sscanf( line, "%[^ ] %[^ ] %[^ ]", method, path, protocol ) != 3 ) //��ȡ������·����Э��
    {   
        close(cfd);
        return 0;
    }

    while ( fgets( line, sizeof(line), fp ) != (char*) 0 )  // ��������ͷ����
	{
	if ( strcmp( line, "\n" ) == 0 || strcmp( line, "\r\n" ) == 0 )
	    break;
	}
    if ( strcasecmp( method, "get" ) != 0 )  // micro_httpdֻ֧��get����
	send_error(fp, 501, "Not Implemented", (char*) 0, "That method is not implemented." );
    if ( path[0] != '/' )  // ·��������б�ܿ�ͷ
	send_error(fp, 400, "Bad Request", (char*) 0, "Bad filename." );
    file = &(path[1]);
    strdecode( file, file ); // ����·�����������micro_httpd�ĸ�Ŀ¼argv[1]
    if ( file[0] == '\0' )
	file = "./";
    len = strlen( file );
// ���·�����Ƿ��Խ����ʵ���Ŀ¼�ϼ�Ŀ¼��..snoop
    if ( file[0] == '/' || strcmp( file, ".." ) == 0 || strncmp( file, "../", 3 ) == 0 || strstr( file, "/../" ) != (char*) 0 || strcmp( &(file[len-3]), "/.." ) == 0 )
	send_error(fp, 400, "Bad Request", (char*) 0, "Illegal filename." );
    if ( stat( file, &sb ) < 0 )  // ���ʵ��ļ�����Ŀ¼��������
	send_error(fp, 404, "Not Found", (char*) 0, "File not found." );
    if ( S_ISDIR( sb.st_mode ) )  // ·������ӦĿ¼
	{
	if ( file[len-1] != '/' )  // Ŀ¼��Ҫ��б�ܽ�β
	    {
	    (void) snprintf(
		location, sizeof(location), "Location: %s/", path );
	    send_error( fp, 302, "Found", location, "Directories must end with a slash." );
	    }
	(void) snprintf( idx, sizeof(idx), "%sindex.html", file );
	if ( stat( idx, &sb ) >= 0 )  // Ŀ¼֮�´���index.html�ļ����򷵻�index.html������
	    {
	    file = idx;
	    goto do_file;
	    }
	send_headers( fp, 200, "Ok", (char*) 0, "text/html", -1, sb.st_mtime );
	(void) fprintf(fp, "<html><head><title>Index of %s</title></head>\n<body bgcolor=\"#99cc99\"><h4>Index of %s</h4>\n<pre>\n", file, file );
	n = scandir( file, &dl, NULL, alphasort );  // ��ȡĿ¼�µĸ���Ŀ¼�������ÿ���ļ�����Ϣ
	if ( n < 0 )
	    perror( "scandir" );
	else
	    for ( i = 0; i < n; ++i )
		file_details(fp,  file, dl[i]->d_name );
	(void) fprintf(fp, "</pre>\n<hr>\n<address><a href=\"%s\">%s</a></address>\n</body></html>\n", SERVER_URL, SERVER_NAME );
	}
    else
	{
	do_file:  // ��ȡ�ļ������ݲ����ظ��ͻ���
	FILE *nfp = fopen( file, "r" );
	if ( nfp == (FILE*) 0 )
	    send_error(fp, 403, "Forbidden", (char*) 0, "File is protected." );
	send_headers(fp,  200, "Ok", (char*) 0, get_mime_type( file ), sb.st_size, sb.st_mtime );
    //char tbuf[1024];
    //while(NULL != fgets(tbuf, 1024,fp)) {
    //     fputs(tbuf, fp);
    //}
    while ( ( ich = getc( nfp ) ) != EOF )
        fputc( ich, fp);
	fclose(nfp);
	}

    (void) fflush( fp);

    close(cfd);

}

/*  ��ȡ�ļ�����Ϣ������Ӧ�ļ��ĳ�������Ϣ  */
static void file_details(FILE *fp, char* dir, char* name )
{
    static char encoded_name[1000];
    static char path[2000];
    struct stat sb;
    char timestr[64];

    strencode( encoded_name, sizeof(encoded_name), name );
    (void) snprintf(path, sizeof(path), "%s/%s", dir, name );
    if ( lstat( path, &sb ) < 0 )
	(void) fprintf(fp, "<a href=\"%s\">%-32.32s</a>    ???\n", encoded_name, name );
    else
    {
		(void) strftime( timestr, sizeof(timestr), "%Y-%m-%d %H:%M", localtime( &sb.st_mtime ) );
        (void) fprintf(fp, "<a href=\"%s\">%-32.32s</a>    %15s %14lld\n", encoded_name, name, timestr, (int64_t) sb.st_size );
	}
}

/* ����ʱ�����ʹ�����Ӧ��Ϣ */
static void
send_error( FILE *fp, int status, char* title, char* extra_header, char* text )
{
    send_headers(fp, status, title, extra_header, "text/html", -1, -1 );
    (void) fprintf(fp, "<html><head><title>%d %s</title></head>\n<body bgcolor=\"#cc9999\"><h4>%d %s</h4>\n", status, title, status, title );
    (void) fprintf(fp, "%s\n", text );
    (void) fprintf(fp,  "<hr>\n<address><a href=\"%s\">%s</a></address>\n</body></html>\n", SERVER_URL, SERVER_NAME );
    (void) fflush( fp );
}

/* ����http��Ӧͷ����Ϣ */
static void
send_headers( FILE *fp, int status, char* title, char* extra_header, char* mime_type, off_t length, time_t mod )
{
    time_t now;
    char timebuf[100];

    (void) fprintf(fp, "%s %d %s\015\012", PROTOCOL, status, title );   // Э�飬״̬������
    (void) fprintf(fp, "Server: %s\015\012", SERVER_NAME );  // Server�ֶ�
    now = time( (time_t*) 0 );
    (void) strftime(timebuf, sizeof(timebuf), RFC1123FMT, gmtime( &now ) );
    (void) fprintf(fp, "Date: %s\015\012", timebuf );  // Date�ֶ�
    if ( extra_header != (char*) 0 )
	(void) fprintf(fp, "%s\015\012", extra_header );
    if ( mime_type != (char*) 0 )
	(void) fprintf(fp, "Content-Type: %s\015\012", mime_type );  // Content-Type�ֶ�
    if ( length >= 0 )
	(void) fprintf(fp, "Content-Length: %lld\015\012", (int64_t) length ); // Content-Length�ֶ�
    if ( mod != (time_t) -1 )
	{
	(void) strftime( timebuf, sizeof(timebuf), RFC1123FMT, gmtime( &mod ) );
	(void) fprintf(fp, "Last-Modified: %s\015\012", timebuf );
	}
    (void) fprintf(fp, "Connection: close\015\012" );
    (void) fprintf(fp, "\015\012" );
}

/* �����ļ�����ȡmime���ͣ�ͨ�������ļ���׺�� */
static char*
get_mime_type( char* name )
{
    char* dot;

    dot = strrchr( name, '.' );
    if ( dot == (char*) 0 )
	return "text/plain; charset=iso-8859-1";
    if ( strcmp( dot, ".html" ) == 0 || strcmp( dot, ".htm" ) == 0 )
	return "text/html; charset=iso-8859-1";
    if ( strcmp( dot, ".jpg" ) == 0 || strcmp( dot, ".jpeg" ) == 0 )
	return "image/jpeg";
    if ( strcmp( dot, ".gif" ) == 0 )
	return "image/gif";
    if ( strcmp( dot, ".png" ) == 0 )
	return "image/png";
    if ( strcmp( dot, ".css" ) == 0 )
	return "text/css";
    if ( strcmp( dot, ".au" ) == 0 )
	return "audio/basic";
    if ( strcmp( dot, ".wav" ) == 0 )
	return "audio/wav";
    if ( strcmp( dot, ".avi" ) == 0 )
	return "video/x-msvideo";
    if ( strcmp( dot, ".mov" ) == 0 || strcmp( dot, ".qt" ) == 0 )
	return "video/quicktime";
    if ( strcmp( dot, ".mpeg" ) == 0 || strcmp( dot, ".mpe" ) == 0 )
	return "video/mpeg";
    if ( strcmp( dot, ".vrml" ) == 0 || strcmp( dot, ".wrl" ) == 0 )
	return "model/vrml";
    if ( strcmp( dot, ".midi" ) == 0 || strcmp( dot, ".mid" ) == 0 )
	return "audio/midi";
    if ( strcmp( dot, ".mp3" ) == 0 )
	return "audio/mpeg";
    if ( strcmp( dot, ".ogg" ) == 0 )
	return "application/ogg";
    if ( strcmp( dot, ".pac" ) == 0 )
	return "application/x-ns-proxy-autoconfig";
    return "text/plain; charset=iso-8859-1";
}

/* ��·�������� */
static void
strdecode( char* to, char* from )
{
    for ( ; *from != '\0'; ++to, ++from )
	{
	if ( from[0] == '%' && isxdigit( from[1] ) && isxdigit( from[2] ) )
	    {
	    *to = hexit( from[1] ) * 16 + hexit( from[2] );
	    from += 2;
	    }
	else
	    *to = *from;
	}
    *to = '\0';
}


static int
hexit( char c )
{
    if ( c >= '0' && c <= '9' )
	return c - '0';
    if ( c >= 'a' && c <= 'f' )
	return c - 'a' + 10;
    if ( c >= 'A' && c <= 'F' )
	return c - 'A' + 10;
    return 0;		/* shouldn't happen, we're guarded by isxdigit() */
}

/* ��·�������룬URL encoding*/
static void
strencode( char* to, size_t tosize, const char* from )
{
    int tolen;

    for ( tolen = 0; *from != '\0' && tolen + 4 < tosize; ++from )
	{
	if ( isalnum(*from) || strchr( "/_.-~", *from ) != (char*) 0 )
	    {
	    *to = *from;
	    ++to;
	    ++tolen;
	    }
	else
	    {
	    (void) sprintf( to, "%%%02x", (int) *from & 0xff );
	    to += 3;
	    tolen += 3;
	    }
	}
    *to = '\0';
}


