#ifndef _TPOLL_TASKER_H
#define _TPOLL_TASKER_H

#include <queue>
#include "server_tasker.h"
#include "common_thread.h"

class tpoll_tasker_t;

class tprocess_thread_t: public common_thread_t {
public:
    tprocess_thread_t(tpoll_tasker_t *tasker);
    ~tprocess_thread_t();
    void run();
private:
    tpoll_tasker_t *_tasker;
    int _cfd;
    proc_func_t _proc;
};

class tpoll_tasker_t: public server_tasker_t {
public:
    tpoll_tasker_t(int thrnum, proc_func_t proc);
    ~tpoll_tasker_t();
    int lock();
    int unlock();
    int notify();
    int wait();
    bool empty();
    int pop();
    void push(int cfd);
    int proc(int cfd);
    int process(int cfd, proc_func_t proc);
private:
    std::queue<int> _taskq;
    pthread_mutex_t _qmtx;
    pthread_cond_t _qcond;
    int _thrnum;
    tprocess_thread_t **_threads;
    proc_func_t _proc;
};


#endif
