#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/epoll.h>

#include "server_frame.h"

server_frame_t::server_frame_t(server_tasker_t *tasker, proc_func_t do_task)
{
    _tasker = tasker;
    _do_task = do_task;
    _lfd = -1;
}

server_frame_t::~server_frame_t()
{
    if(_lfd > 0) {
        close(_lfd);
        _lfd = -1;
    }
    delete _tasker;
}

int server_frame_t::tcp_server(std::string ip, uint16_t port)
{
 	 _lfd = socket(AF_INET, SOCK_STREAM, 0);
	if(_lfd < 0) {
		perror("socket");
		return -1;
	}

	int ret = 0;
	struct sockaddr_in addr;
	memset(&addr, 0, sizeof(struct sockaddr_in));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = inet_addr(ip.c_str());
	addr.sin_port = htons(port);

    // set reuse address flag
    int optval = 1;
    setsockopt(_lfd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval));

    // bind address
	ret = bind(_lfd, (struct sockaddr *)&addr, sizeof(addr));
	if(ret < 0) {
		perror("bind");
		return - 1;
	}

    // listen
	ret = listen(_lfd, 128);
	if(ret < 0) {
		perror("bind");
		return - 1;
	}   

    return 0;
}

int server_frame_t::loop_task()
{
    const int MAX_EVENT_COUNT = 1024;
    struct epoll_event events[MAX_EVENT_COUNT];
    int epfd = epoll_create(MAX_EVENT_COUNT);
    int ret = 0;
    int reqnum = 0;

    // add listenfd to epoll set
    struct epoll_event lev;
    lev.events = EPOLLIN;
    lev.data.fd = _lfd;
    ret = epoll_ctl(epfd, EPOLL_CTL_ADD, _lfd, &lev);
    if(ret < 0) {
        perror("epoll_ctl");
        return -1;
    }

    struct sockaddr_in clnt_addr;
    unsigned int addr_len = 0;

    while(1) {
        // wait event 
        int nfds = epoll_wait(epfd, events, MAX_EVENT_COUNT, -1);
        for(int i = 0; i < nfds; i++) {
            if(events[i].data.fd == _lfd) {  // listen fd is active
                int cfd = accept(_lfd, (struct sockaddr *)(&clnt_addr), &addr_len);
                if(cfd < 0) {
                    continue;
                }
                printf("%dth request from: <%s:%d>\n",
                        ++reqnum,
                        inet_ntoa(clnt_addr.sin_addr),
                        ntohs(clnt_addr.sin_port));

                struct epoll_event ev;
                ev.events = EPOLLIN;
                ev.data.fd = cfd;
                ret = epoll_ctl(epfd, EPOLL_CTL_ADD, cfd, &ev);
                if(ret < 0) {
                    perror("epoll_ctl");
                }
            } else {                      // client fd is active
                // it's will be moved out autoly when close
                ret = epoll_ctl(epfd, EPOLL_CTL_DEL, events[i].data.fd, &events[i]);
                if(ret < 0) {
                    perror("epoll_ctl");
                }
                _tasker->process(events[i].data.fd, _do_task);
            }
        }
    }

    return 0;
}
