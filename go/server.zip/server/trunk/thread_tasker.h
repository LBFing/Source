#ifndef _THREAD_TASKER_H
#define _THREAD_TASKER_H

#include "common_thread.h"
#include "server_tasker.h"

class process_thread_t: public common_thread_t {
public:
    process_thread_t(int cfd, proc_func_t proc)
    {
        _proc = proc;
        _cfd = cfd;

    }

    virtual void run()
    {
        _proc(_cfd);
    }
private:
    proc_func_t _proc;
    int _cfd;
};

class thread_tasker_t: public server_tasker_t {
public:
    int process(int cfd, proc_func_t proc);
};

#endif
