#include <time.h>

#include "request_thread.h"
#include "trace_player.h"

int main(int argc, char *argv[])
{
    if(2 != argc) {
        printf("./mclient trace_file\n");
        return -1;
    }
    
    trace_player_t tracer(argv[1]);
    tracer.play();
    
    printf("avg serve time: %ldus\n",
            request_thread_t::reqtime / request_thread_t::reqnum);

    return 0;
}
