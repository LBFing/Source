#include <stdio.h>
#include "simple_tasker.h"

int simple_tasker_t::process(int cfd, proc_func_t proc) 
{
    return proc(cfd);
}
