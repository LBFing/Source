#include "tpoll_tasker.h"

tprocess_thread_t::tprocess_thread_t(tpoll_tasker_t *tasker)
{   
    _tasker = tasker;
}

tprocess_thread_t::~tprocess_thread_t()
{

}

void tprocess_thread_t::run()
{
    while(1) {
        _tasker->lock();
        while(true == _tasker->empty()) {
            _tasker->wait();
        }

        int cfd = _tasker->pop();
        _tasker->unlock();
        _tasker->proc(cfd);
    }
}

tpoll_tasker_t::tpoll_tasker_t(int thrnum, proc_func_t proc)
{
    _thrnum = thrnum;
    _proc = proc;
    pthread_mutex_init(&_qmtx, NULL);
    pthread_cond_init(&_qcond, NULL);
    
    _threads = (tprocess_thread_t **)malloc(sizeof(tprocess_thread_t *) * _thrnum);
    if(NULL == _threads) {
        return;
    }

    for(int i = 0; i < _thrnum; i++) {
        printf("serve thread %d created\n", i+1);
        _threads[i] = new tprocess_thread_t(this);
        _threads[i]->start();
    }
}

tpoll_tasker_t::~tpoll_tasker_t()
{
    for(int i = 0; i < _thrnum; i++) {
        _threads[i]->join();
        printf("serve thread %d terminated\n");
    }
    
    for(int i =  0; i < _thrnum; i++) {
        delete _threads[i];
    }

    free(_threads);

    pthread_mutex_destroy(&_qmtx);
    pthread_cond_destroy(&_qcond);
}

int tpoll_tasker_t::lock()
{
    return pthread_mutex_lock(&_qmtx);
}

int tpoll_tasker_t::unlock()
{
    return pthread_mutex_unlock(&_qmtx);
}

int tpoll_tasker_t::notify()
{
    return pthread_cond_signal(&_qcond);
}

int tpoll_tasker_t::wait()
{
    return pthread_cond_wait(&_qcond, &_qmtx);
}

bool tpoll_tasker_t::empty()
{
    return (0 == _taskq.size());
}

int tpoll_tasker_t::pop()
{
    int cfd = _taskq.front();
    _taskq.pop();
    return cfd;
}

void tpoll_tasker_t::push(int cfd)
{
    _taskq.push(cfd);
}

int tpoll_tasker_t::proc(int cfd)
{
    return _proc(cfd);
}

int tpoll_tasker_t::process(int cfd, proc_func_t proc)
{
    (void)proc;
    lock();
    push(cfd);
    unlock();
    notify();
}
