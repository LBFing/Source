#include "common_thread.h"

class print_thread_t: public common_thread_t {
public:
    void run();
};

void print_thread_t::run()
{
    for(int i = 0; i < 10; i++) {
        printf("hello world\n");
    }
}


void thread_test()
{
    print_thread_t thread;
    thread.start();
    thread.join();
}

int main()
{
    thread_test();
    return 0;
}
