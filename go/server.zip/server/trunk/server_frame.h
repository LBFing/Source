#ifndef _SERVER_FRAME_H
#define _SERVER_FRAME_H

#include <string>
#include "server_tasker.h"

/**
 * @brief server frame work
 */
class server_frame_t {
public:
    server_frame_t(server_tasker_t *tasker, proc_func_t do_task);
    ~server_frame_t();
    int tcp_server(std::string ip = "127.0.0.1", 
            uint16_t port = 12340);
    int loop_task();
private:
    int _lfd;
    server_tasker_t *_tasker;  // tasker
    proc_func_t _do_task;     // proc
    
};

#endif
