#ifndef _REQUEST_THREAD_H
#define _REQUEST_THREAD_H

#include <stdint.h>
#include "common_type.h"
#include "common_thread.h"


/**
 * @brief request thread class
 */
class request_thread_t: public common_thread_t {
public:
    request_thread_t() 
    {
        _request.offset = 0;
        _request.size = 0;
        _address.ip = "127.0.0.1";
        _address.port = 12340;
    }

    ~request_thread_t()
    {
    }

    virtual void run();

    void set_request(uint64_t offset, uint64_t size)
    {
        _request.offset = offset;
        _request.size = size;
    }

    void set_address(const char *ip, uint16_t port)
    {
        _address.ip = ip;
        _address.port = port;
    }
private:
    request_t _request;
    address_t _address;
    static pthread_mutex_t mtx;
public:
    volatile static uint64_t reqnum;
    volatile static uint64_t reqtime;
};

#endif

