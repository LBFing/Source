#ifndef _SIMPLE_TASKER_H
#define _SIMPLE_TASKER_H

#include "server_tasker.h"

class simple_tasker_t: public server_tasker_t {
public:
    virtual int process(int cfd, proc_func_t proc);
};

#endif
