#include "common_thread.h"

void * common_thread_t::_process(void *data)
{
    common_thread_t *thread = (common_thread_t *)data;
    thread->run();
}

int common_thread_t::start()
{
    int ret = pthread_create(&_pid, NULL, _process, (void *)this);
    if(ret < 0) {
        perror("pthread_create");
        return -1;
    }
    return 0;
}

int common_thread_t::join(void **val_ptr)
{
    int ret = pthread_join(_pid, val_ptr);
    if(ret < 0) {
        perror("pthread_create");
        return -1;
    }
    return 0;
}

int common_thread_t::detach()
{
    int ret = 0;
    ret = pthread_detach(_pid);
    if(ret < 0) {
        perror("pthread_detach");
        return -1;
    }
    
    return 0;
}

pthread_t common_thread_t::getpid()
{
    return _pid;
}
