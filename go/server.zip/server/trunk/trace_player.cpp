#include <string.h>
#include <stdint.h>
#include <time.h>

#include "request_thread.h"
#include "trace_player.h"

trace_player_t::trace_player_t(const char *file)
{
    _fp = fopen(file, "r");
    if(NULL == _fp) {
        printf("fopen error\n");
    }
}

trace_player_t::~trace_player_t()
{
    if(NULL != _fp) {
        fclose(_fp);
    }
}

void trace_player_t::play()
{
    double lwhence = 0.0;
    char line[1024];

    uint64_t offset = 0;
    uint64_t size = 0;
    double whence = 0;
    printf("%p\n", _fp);
    while(NULL != fgets(line, 1024, _fp)) {
       line[strlen(line)-1] = '\0'; 
       sscanf(line, "%*d,%llu,%llu,%*c,%lf", &offset, &size, &whence);
       //printf("%llu %llu %lf\n", offset, size, whence);
     
       // sleep a while
       struct timespec ts;
       uint64_t interval = (uint64_t)((whence - lwhence) * 1000000000);
       ts.tv_sec = interval / 1000000000;
       ts.tv_nsec = interval % 1000000000;
       nanosleep(&ts, NULL);
       lwhence = whence;
        
       // send request
       request_thread_t *thread = new request_thread_t();  // memory leak here
       thread->set_request(offset, size);
       thread->set_address("192.168.0.79", 12340);
       thread->start();
       thread->detach();
    }
}




