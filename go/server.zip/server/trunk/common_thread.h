#ifndef _COMMON_THREAD_H
#define _COMMON_THREAD_H

#include <sys/types.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

/**
* @brief common thread 
*/
class common_thread_t {
public:

    /**
     * @brief constructor
     */
    common_thread_t() 
    {
        _pid = 0;
    }
    

    /**
     * @brief virtual destructor
     */
    virtual ~common_thread_t() 
    {
        _pid = 0;
    }


    /**
     * @brief thread_task
     */
    virtual void run() = 0;


    /**
     * @brief start a thread
     *
     * @return 
     */
    int start();


    /**
     * @brief join a thread
     *
     * @return 
     */
    int join(void **val_ptr = NULL);


    /**
     * @brief detach thread
     *
     * @return 
     */
    int detach();


    /**
     * @brief get thread id
     *
     * @return 
     */
    pthread_t getpid();
private:
    static void *_process(void *data);
private:
    pthread_t _pid;
};

#endif
