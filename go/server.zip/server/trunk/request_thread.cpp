#include <unistd.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string>

#include "request_thread.h"

volatile uint64_t request_thread_t::reqnum = 0;     // count
volatile uint64_t request_thread_t::reqtime = 0;    // us
pthread_mutex_t request_thread_t::mtx = PTHREAD_MUTEX_INITIALIZER;

void request_thread_t::run()
{
    int cfd = socket(AF_INET, SOCK_STREAM, 0);
    if(cfd < 0) {
        perror("socket");
        return;
    }

    printf("address-<%s:%u>\n", _address.ip.c_str(), _address.port);
    printf("request--<%lu:%lu>\n", _request.offset, _request.size);

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(struct sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr(_address.ip.c_str());
    addr.sin_port = htons(_address.port);
    
    int ret = connect(cfd, (struct sockaddr *)&addr, sizeof(addr));
    if(ret < 0) {
        perror("connect");
        return;
    }

    struct timeval start, end;

    // record request start time
    gettimeofday(&start, NULL);
    
    int rlen = 0, wlen = 0;
    wlen = write(cfd, &_request, sizeof(_request));
    if(wlen != sizeof(_request)) {
        perror("write");
        return;
    }

    char *buf = (char *)malloc(_request.size * sizeof(char));
    if(NULL == buf) {
        perror("malloc");
        return;
    }

    int ridx = 0;
    while(ridx < _request.size) {
        rlen = read(cfd, buf + ridx, _request.size - ridx);
        if(rlen < 0) {
            perror("read");
        }
        ridx += rlen;
    }

    // request end time
    gettimeofday(&end, NULL);

    uint64_t serve_time =  (end.tv_sec - start.tv_sec) * 1000000 +
            (end.tv_usec - start.tv_usec);

    printf("length: %lu, time: %luus\n", _request.size, serve_time);
    
    pthread_mutex_lock(&mtx);
    reqnum++;
    reqtime += serve_time;
    pthread_mutex_unlock(&mtx);

    free(buf);
    close(cfd);
}

