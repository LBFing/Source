#include <stdio.h>

class trace_player_t {
public:
    trace_player_t(const char *file);
    ~trace_player_t();
    void play();
private:
    FILE *_fp;
};
