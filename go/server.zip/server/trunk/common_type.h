#ifndef _COMMON_TYPE_H
#define _COMMON_TYPE_H

#include <string>

/**
 * @brief request information
 */
struct request_t {
    uint64_t offset;
    uint64_t size;
};


/**
 * @brief address information
 */
struct address_t {
    std::string ip;
    uint16_t port;
};

#endif
