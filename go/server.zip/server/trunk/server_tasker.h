#ifndef _COMMON_TASKER_H
#define _COMMON_TASKER_H

typedef int (*proc_func_t)(int cfd);

/**
* @brief tasker base
*/
class server_tasker_t {
public:
    server_tasker_t() 
    {
    }

    virtual ~server_tasker_t()
    {
    }
    
    virtual int process(int cfd, proc_func_t proc) = 0;
};

#endif
