#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <stdint.h>

#include "server_frame.h"
#include "simple_tasker.h"
#include "thread_tasker.h"
#include "tpoll_tasker.h"
#include "common_type.h"

int read_content(const char *file, uint64_t offset, uint64_t size, char *buf)
{
    int fd = open(file, O_RDONLY);
    if(fd < 0) {
        perror("open");
        return -1;
    }

    lseek(fd, offset, SEEK_SET);
    uint64_t rlen = read(fd, buf, size);
    if(rlen != size) {
        perror("read_content");
    }
    close(fd);
    return rlen;
}

int do_task(int cfd)
{
    //long flag = fcntl(cfd, F_GETFL);
    //fcntl(cfd, F_SETFL, flag | O_NONBLOCK);
    
    int rlen = 0, wlen = 0;
    char buf[128 * 1024] = "hello world";

    request_t req;
    rlen = read(cfd, &req, sizeof(req));
    if(0 == rlen) {
        close(cfd);
        return 0;
    } else if(rlen != sizeof(req)) {
        return 0;
    }

    rlen = read_content("/dev/sdc9", req.offset, req.size, buf);

    int widx = 0;
    while(widx < req.size) {
        wlen = write(cfd, buf + widx, req.size - widx);
        widx += wlen;
    }

    close(cfd);

    return 0;
}

int main()
{
    server_frame_t server(new tpoll_tasker_t(5, do_task), do_task);
    server.tcp_server("192.168.0.79", 12340);
    server.loop_task();
    return 0;
}
